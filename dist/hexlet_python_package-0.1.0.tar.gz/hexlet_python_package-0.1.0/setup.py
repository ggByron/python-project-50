# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['hexlet-python-package = '
                     'hexlet_python_package.scripts.hexlet_python_package:main']}

setup_kwargs = {
    'name': 'hexlet-python-package',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/ggByron/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/ggByron/python-project-50/actions)',
    'author': 'ggByron',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
